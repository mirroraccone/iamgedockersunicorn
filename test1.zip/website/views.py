from flask import Blueprint, render_template, request, flash, redirect, url_for, jsonify
from flask_login import login_required, current_user
from .models import User
from . import db
from . import create_app
from flask_mail import Message

views = Blueprint("views", __name__)


@views.route("/")
@views.route("/home")
def home():
    return render_template("index.html",user=current_user)

@views.route("/web_guide")
def web_guide():
    return render_template("guide.html",user=current_user)

@views.route("/live-water_quality")
@login_required
def water_quality():
    return render_template("water_quality.html",user=current_user)

@views.route("/live-soil")
@login_required
def soil():
    return render_template("soil.html",user=current_user)

@views.route("/static-waterbodies")
@login_required
def waterbodies():
    return render_template("waterbodies.html",user=current_user)

@views.route("/activity")
def activity():
    return render_template("activity.html",user=current_user)

@views.route("/live-maps")
@login_required
def maps():
    return render_template("maps.html",user=current_user)

@views.route("/team")
def team():
    return render_template("team.html",user=current_user)



@views.route("/contact",methods=['GET', 'POST'])
def contact():
    if request.method == 'POST':
        sender_name = request.form.get("sender_name")
        sender_email = request.form.get("sender_email")
        sender_message = request.form.get("sender_message")
        
        msg = Message(
                'Nallampatti',
                sender =(sender_name ,sender_email),
                recipients = ['karmathecoder@gmail.com'],
                body= sender_message
                
               )
        create_app.mail.send(msg)
        return render_template("contact_us.html", submit_msg="Thank you for submitting your response. We will be in touch with you shortly." , user=current_user)

    return render_template("contact_us.html",user=current_user)



